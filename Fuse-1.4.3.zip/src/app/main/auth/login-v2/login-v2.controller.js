(function ()
{
    'use strict';

    angular
        .module('app.login')
        .controller('LoginV2Controller', LoginV2Controller);

    /** @ngInject */
    function LoginV2Controller(api, $location, $cookies, AlertService)
    {
        // Data

        // Methods

        //////////
        var vm = this;
        vm.login = login;
        //////////

        function login() {
          // console.log(vm.form)
          api.auth.login.save(vm.form,
         
               // Success
               function (response)
               {
                // console.log(response.user)
                  $cookies.putObject('user', response.user);
                  $cookies.put('token', response.access_token);
                  if(response.user.role == 'admin') {
                    $location.path('category');
                  } else {
                    $location.path('lists');
                  }
               },
 
               // Error
               function (response)
               {
                AlertService.displayErrors(response);
                   //console.error(response);
               }
           );
        }
    }
})();