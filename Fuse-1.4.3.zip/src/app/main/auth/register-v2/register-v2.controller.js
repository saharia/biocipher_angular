(function ()
{
    'use strict';

    angular
        .module('app.register')
        .controller('RegisterV2Controller', RegisterV2Controller);

    /** @ngInject */
    function RegisterV2Controller(api, $location, AlertService)
    {
      // console.log(api)
        // Data
        // Methods
        var vm = this;
        vm.register = register;
        //////////

        function register() {
          // console.log(vm.form)
          api.auth.register.save(vm.form,
         
               // Success
               function (response)
               {
                AlertService.success("Account Created");
                  $location.path('/');
               },
 
               // Error
               function (response)
               {
                AlertService.displayErrors(response);
                   //console.error(response);
               }
           );
        }
    }
})();