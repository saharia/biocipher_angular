(function ()
{
    'use strict';

    angular
        .module('app.lists', [  ])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider)
    {
      var $cookie = angular.injector(["ngCookies"]).get("$cookies");
      var user = $cookie.getObject('user');
        // State
        $stateProvider
            .state('app.lists', {
                url    : '/lists',
                views  : {
                    'content@app': {
                        templateUrl: 'app/main/lists/lists.html',
                        controller : 'ListsController as vm'
                    }
                },
                resolve: {
                    ListsData: function (apiResolver)
                    {
                        return apiResolver.resolve('product.getAll@get');
                    }
                }
            });

        // Translation
        //$translatePartialLoaderProvider.addPart('app/main/lists');

        // Api
        // msApiProvider.register('lists', ['app/data/lists/lists.json']);

        // Navigation
        // console.log(user.role)
        if(user && user.role == 'user') {
          msNavigationServiceProvider.saveItem('fuse.lists', {
              title    : 'Lists',
              icon     : 'icon-tile-four',
              state    : 'app.lists',
              weight   : 1
          });
        }
    }
})();