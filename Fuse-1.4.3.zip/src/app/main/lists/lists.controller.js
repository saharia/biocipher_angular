(function ()
{
    'use strict';

    angular
        .module('app.lists')
        .controller('ListsController', ListsController);

    /** @ngInject */
    function ListsController(ListsData, api)
    {
        var vm = this;
        vm.products = ListsData.products;
        vm.offset = 0;
        vm.loadMore = loadMore;
        vm.is_data_exists = ListsData.is_data_exists;
        // Data

        // Methods
        function loadMore() {
          console.log('more')
          if(vm.is_data_exists) {
            vm.offset += 20;
            api.product.getAll.get({ offset: vm.offset },
         
               // Success
               function (response)
               {
                 vm.products = vm.products.concat(response.products);
                 /*var data = response.product;
                 for (var i=0; i<data.length; i++){
                     vm.products.push(data[i]);
                  }*/
                 vm.is_data_exists = response.is_data_exists;
               },
 
               // Error
               function (response)
               {
                   //console.error(response);
               }
           );
          }
        }
        //////////
    }
})();
