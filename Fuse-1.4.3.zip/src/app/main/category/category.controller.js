(function ()
{
    'use strict';

    angular
        .module('app.category')
        .controller('CategoryController', CategoryController);

    /** @ngInject */
    function CategoryController(api, $location, $cookies, $scope, AlertService)
    {
      // console.log(AlertService.success())
        var vm = this;
        vm.category = category;
        vm.product = product;
        vm.loadCategory = loadCategory;
        vm.categoryLists = [];
        vm.files = [];
        // Data
        // vm.helloText = SampleData.data.helloText;
        // vm.CategoryData = CategoryData.categories;
        // Methods

        //////////

        $scope.getFileDetails = function (e) {

            vm.files = [];
            $scope.$apply(function () {

                // STORE THE FILE OBJECT IN AN ARRAY.
                for (var i = 0; i < e.files.length; i++) {
                    vm.files.push(e.files[i])
                }

            });
        };

        function loadCategory() {
          api.category.getAll.get({},
         
               // Success
               function (response)
               {
                vm.categoryLists = response.categories;
               },
 
               // Error
               function (response)
               {
                   //console.error(response);
               }
           );
        }
        function category() {
           api.category.save.save(vm.cform,
         
               // Success
               function (response)
               {
                AlertService.success('Category added');
                vm.cform = {};
                $scope.categoryForm.$setPristine();
                $scope.categoryForm.$setValidity();
                $scope.categoryForm.$setUntouched();
                console.log(response)
               },
              //INSERT INTO products (category_id,name,price, quantity,description) values (2,'sadfadf',12,12,'sdfdsaf')
               // Error
               function (response)
               {
                AlertService.displayErrors(response);
                   //console.error(response);
               }
           );
        }

        function product() {
          // console.log(vm.files);
          var data = new FormData(angular.element('#productForm')[0]);
          data.append('category_id', vm.pform.category_id);
          for (var i in vm.files) {
              data.append("images[]", vm.files[i]);
          }
           api.product.save.save(data,
         
               // Success
               function (response)
               {
                AlertService.success('Products added');
                vm.pform = {};
                $scope.productForm.$setPristine();
                $scope.productForm.$setValidity();
                $scope.productForm.$setUntouched();
               },
 
               // Error
               function (response)
               {
                AlertService.displayErrors(response);
                   //console.error(response);
               }
           );
        }
    }
})();
