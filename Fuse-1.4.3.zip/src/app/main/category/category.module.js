(function ()
{
    'use strict';

    angular
        .module('app.category', [])
        .config(config);

    /** @ngInject */
    function config($stateProvider, $translatePartialLoaderProvider, msApiProvider, msNavigationServiceProvider, $cookiesProvider)
    {
      // var user = $cookiesProvider.get('user');
      var $cookie = angular.injector(["ngCookies"]).get("$cookies");
      var user = $cookie.getObject('user');
        // State
        $stateProvider
            .state('app.category', {
                url    : '/category',
                views  : {
                    'content@app': {
                        templateUrl: 'app/main/category/category.html',
                        controller : 'CategoryController as vm'
                    }
                }/*,
                resolve: {
                    CategoryData: function (apiResolver)
                    {
                        return apiResolver.resolve('category.getAll@get');
                    }
                }*/
            });

        // Translation
        //$translatePartialLoaderProvider.addPart('app/main/sample');

        // Api
        // msApiProvider.register('sample', ['app/data/sample/sample.json']);
        // Navigation
        msNavigationServiceProvider.saveItem('fuse', {
            title : 'SAMPLE',
            group : true,
            weight: 1
        });

        if(user && user.role == 'admin') {
          msNavigationServiceProvider.saveItem('fuse.category', {
              title    : 'Category',
              icon     : 'icon-tile-four',
              state    : 'app.category',
              /*stateParams: {
                  'param1': 'page'
               },*/
              // translate: 'SAMPLE.SAMPLE_NAV',
              weight   : 1
          });
        }
    }
})();