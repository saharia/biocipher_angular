(function ()
{
    'use strict';

    angular
        .module('fuse')
        .controller('MainController', MainController)
        .service('AlertService', AlertService)
        .directive("whenScrolled", whenScrolled)
        .service('User', User);

    /** @ngInject */
    function MainController($scope, $rootScope, $cookies)
    {
        // Data

        //////////

        // Remove the splash screen
        $scope.$on('$viewContentAnimationEnded', function (event)
        {
            if ( event.targetScope.$id === $scope.$id )
            {
                $rootScope.$broadcast('msSplashScreen::remove');
            }
        });
    }

    function whenScrolled() {
       return function(scope, elm, attr) {
          var raw = elm[0];

          elm.bind('scroll', function() {
              if (raw.scrollTop + raw.offsetHeight >= raw.scrollHeight) {
                  scope.$apply(attr.whenScrolled);
              }
          });
      };
    }
    function User($cookies) {
      var obj = {
        getData: function() {
          var data = $cookies.getObject('user');
          return data;
        }
      }
      return obj;
    }
    function AlertService($mdToast) {
      //return function($scope, $mdToast) {
        var obj = {
          displayErrors: function(error) {
            if(error.data) {
              var data = error.data;
              if(data.errors) {
                var first_index = Object.keys(data.errors)[0];
                var first_error = data.errors[first_index][0];
                if(first_error) {
                  this.error(first_error);
                }
              } else {
                if(data.msg) {
                  this.error(data.msg);
                }
                if(data.message) {
                  this.error(data.message);
                }
              }
            }
          },
          success: function (msg) {
          // var pinTo = this.getToastPosition();
          var toast = $mdToast.simple()
            .textContent(msg)
            .highlightClass('md-warn')// Accent is used by default, this just demonstrates the usage.
            .position('bottom left')
            .theme("success-toast");
            $mdToast.show(toast);
        },
        error: function (msg) {
          // var pinTo = this.getToastPosition();
          var toast = $mdToast.simple()
            .textContent(msg)
            .highlightClass('md-warn')// Accent is used by default, this just demonstrates the usage.
            .position('bottom left')
            .theme("error-toast");
            $mdToast.show(toast);
        }
        };

        return obj;
      
    }
})();