(function ()
{
    'use strict';

    angular
        .module('fuse')
        .controller('IndexController', IndexController);

    /** @ngInject */
    function IndexController(fuseTheming, $location, $cookies)
    {
        var vm = this;

        // Data
        vm.themes = fuseTheming.themes;

        var path = $location.path();
        var $data = $cookies.getObject('user');
        console.log($data)
        if(path == '/' || path == '/register') {
          if($data && $data.id) {
            if($data.role == 'admin') {
              $location.path('/category');
            } else {
              $location.path('/lists');
            }
          }
        } else {
          if(!$data || !$data.id) {
            $location.path('/'); 
          } else {
            if(path == '/category' && $data.role == 'user') {
              console.log('test')
              $location.path('/lists');
            }
            if(path == '/lists' && $data.role == 'admin') {
              console.log('user for admin')
              $location.path('/category');
            }
          }
        }
        //////////
    }
})();